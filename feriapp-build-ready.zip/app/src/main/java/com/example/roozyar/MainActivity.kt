package com.example.roozyar

import android.app.*
import android.content.*
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.*
import android.widget.*
import java.util.Calendar

class MainActivity : Activity() {
    private lateinit var tasksBox: LinearLayout
    private lateinit var forgottenBox: LinearLayout
    private lateinit var progress: ProgressBar
    private lateinit var progressText: TextView
    private lateinit var scoreText: TextView
    private val prefs by lazy { getSharedPreferences("roozyar", MODE_PRIVATE) }

    data class Task(var title:String, var done:Boolean=false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL

        tasksBox = findViewById(R.id.tasks)
        forgottenBox = findViewById(R.id.forgotten)
        progress = findViewById(R.id.progressBar)
        progressText = findViewById(R.id.tvProgress)
        scoreText = findViewById(R.id.tvScore)

        val d = JalaliCalendar.today()
        findViewById<TextView>(R.id.tvDate).text = "امروز، ${d.year}/${"%02d".format(d.month)}/${"%02d".format(d.day)}"
        setupCalendar(d)
        loadTasks()
        findViewById<Button>(R.id.addTask).setOnClickListener { addTaskDialog() }

        val notes = findViewById<EditText>(R.id.notes)
        notes.setText(prefs.getString("notes",""))
        notes.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) prefs.edit().putString("notes",notes.text.toString()).apply()
        }

        if (android.os.Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 10)
    }

    private fun setupCalendar(d:JalaliCalendar.Date) {
        val box = findViewById<LinearLayout>(R.id.calendar)
        val days = arrayOf("ش","ی","د","س","چ","پ","ج")
        val row = LinearLayout(this); row.orientation=LinearLayout.HORIZONTAL
        days.forEach { addCell(row,it,false) }; box.addView(row)
        // A compact 7-day strip centered on today, with persistent checkboxes.
        val row2 = LinearLayout(this); row2.orientation=LinearLayout.HORIZONTAL
        for(i in -3..3) {
            val day = d.day+i
            val cb = CheckBox(this)
            cb.text = if(i==0) "امروز\n${d.day}" else "$day"
            cb.textSize=12f; cb.gravity=Gravity.CENTER
            cb.layoutParams=LinearLayout.LayoutParams(0,90,1f)
            cb.isChecked = prefs.getBoolean("cal_$day",false)
            cb.setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("cal_$day",checked).apply()
            }
            row2.addView(cb)
        }
        box.addView(row2)
    }

    private fun addCell(row:LinearLayout, text:String, checked:Boolean) {
        val t=TextView(this); t.text=text; t.gravity=Gravity.CENTER
        t.textSize=12f; t.layoutParams=LinearLayout.LayoutParams(0,50,1f)
        row.addView(t)
    }

    private fun loadTasks() {
        tasksBox.removeAllViews(); forgottenBox.removeAllViews()
        val raw = prefs.getString("tasks","") ?: ""
        val list = if(raw.isBlank()) mutableListOf() else raw.split("||").mapNotNull {
            val p=it.split("::",limit=2); if(p.size==2) Task(p[0],p[1]=="1") else null
        }.toMutableList()
        if(list.isEmpty()) {
            list.add(Task("یک کار مهم برای امروز"))
            list.add(Task("۳۰ دقیقه مطالعه"))
            saveTasks(list)
        }
        list.forEachIndexed { i,t -> addTaskView(list,i,t) }
        updateProgress(list)
    }

    private fun addTaskView(list:MutableList<Task>, index:Int, t:Task) {
        val cb=CheckBox(this)
        cb.text=t.title; cb.textSize=16f; cb.setPadding(8,10,8,10)
        cb.isChecked=t.done; cb.setOnCheckedChangeListener { _,checked ->
            list[index].done=checked; saveTasks(list); updateProgress(list)
        }
        tasksBox.addView(cb)
    }

    private fun saveTasks(list:List<Task>) {
        prefs.edit().putString("tasks",list.joinToString("||"){"${it.title}::${if(it.done)1 else 0}"}).apply()
    }

    private fun updateProgress(list:List<Task>) {
        val done=list.count{it.done}; val pct=if(list.isEmpty())0 else done*100/list.size
        progress.progress=pct; progressText.text="پیشرفت امروز $pct٪"; scoreText.text="$done از ${list.size} انجام‌شده"
    }

    private fun addTaskDialog() {
        val input=EditText(this); input.hint="عنوان کار"; input.inputType=InputType.TYPE_CLASS_TEXT
        AlertDialog.Builder(this).setTitle("کار جدید").setView(input)
            .setPositiveButton("افزودن"){_,_->
                val s=input.text.toString().trim()
                if(s.isNotEmpty()) {
                    val old=prefs.getString("tasks","")?:""
                    val value=if(old.isBlank()) "$s::0" else "$old||$s::0"
                    prefs.edit().putString("tasks",value).apply()
                    loadTasks()
                    scheduleReminder(s)
                }
            }.setNegativeButton("لغو",null).show()
    }

    private fun scheduleReminder(title:String) {
        val cal=Calendar.getInstance().apply { add(Calendar.MINUTE, 5) }
        val intent=Intent(this,ReminderReceiver::class.java).putExtra("title",title)
        val pi=PendingIntent.getBroadcast(this,System.currentTimeMillis().toInt(),intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val am=getSystemService(ALARM_SERVICE) as AlarmManager
        if(android.os.Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) {
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
        } else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.timeInMillis,pi)
    }
}
