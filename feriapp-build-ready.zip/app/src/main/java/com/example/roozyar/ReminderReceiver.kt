package com.example.roozyar

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel("tasks","یادآوری کارها",NotificationManager.IMPORTANCE_HIGH)
        nm.createNotificationChannel(channel)
        val title = intent.getStringExtra("title") ?: "یادآوری"
        nm.notify(System.currentTimeMillis().toInt(),
            NotificationCompat.Builder(context,"tasks")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("feriapp")
                .setContentText(title)
                .setAutoCancel(true).build())
    }
}
