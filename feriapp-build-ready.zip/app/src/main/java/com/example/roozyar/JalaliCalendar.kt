package com.example.roozyar

import java.util.Calendar

object JalaliCalendar {
    private val breaks = intArrayOf(-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210,
        1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178)

    data class Date(val year:Int,val month:Int,val day:Int)

    fun today(): Date {
        val c = Calendar.getInstance()
        return gregorianToJalali(c.get(Calendar.YEAR), c.get(Calendar.MONTH)+1, c.get(Calendar.DAY_OF_MONTH))
    }

    fun gregorianToJalali(gy:Int, gm:Int, gd:Int):Date {
        var jy: Int
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + 365*gy + (gy2+3)/4 - (gy2+99)/100 + (gy2+399)/400 + gd
        val gdm = intArrayOf(0,31,28,31,30,31,30,31,31,30,31,30,31)
        for(i in 1 until gm) days += gdm[i]
        var j = -1595 + 33*(days/12053)
        var r = days % 12053
        j += 4*(r/1461)
        r %= 1461
        if(r > 365) {
            j += (r-1)/365
            r = (r-1)%365
        }
        var m = if(r < 186) 1 + r/31 else 7 + (r-186)/30
        val d = 1 + if(r < 186) r%31 else (r-186)%30
        jy=j
        return Date(jy,m,d)
    }
}
