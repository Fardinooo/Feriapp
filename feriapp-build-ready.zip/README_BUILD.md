# feriapp — Android build
این پروژه برای Build ابری آماده شده است.
نام اپ: feriapp
Application ID: com.example.feriapp

خروجی مورد نظر:
app/build/outputs/apk/debug/app-debug.apk

نکته: سرویس Build باید Gradle/Android SDK را خودش فراهم کند؛ wrapper این بسته عمداً به Gradle نصب‌شده در محیط متکی است.
